# Demo Checklist

- [ ] Show repository name `CODSOFT_TASKSNO`
- [ ] Show all five task folders
- [ ] Run Task 1 and demonstrate high/low feedback
- [ ] Run Task 2 and demonstrate +, -, *, /
- [ ] Run Task 3 and demonstrate a winning move
- [ ] Run Task 4 and demonstrate add/view/complete/remove
- [ ] Run Task 5 and demonstrate create/load/filter/save
- [ ] Show README.md
- [ ] Show GitHub repository after pushing
- [ ] If posting on LinkedIn, include `#codsoft` as requested in the internship brief
