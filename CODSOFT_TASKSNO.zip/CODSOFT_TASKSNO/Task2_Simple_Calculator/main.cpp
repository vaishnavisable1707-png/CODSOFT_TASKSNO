#include <iostream>
#include <limits>

double readNumber(const std::string& prompt) {
    double value;

    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            return value;
        }

        std::cout << "Invalid number. Try again.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

int main() {
    char again = 'y';

    std::cout << "=================================\n";
    std::cout << "        SIMPLE CALCULATOR\n";
    std::cout << "=================================\n";

    while (again == 'y' || again == 'Y') {
        const double a = readNumber("Enter first number: ");
        const double b = readNumber("Enter second number: ");

        char operation;
        std::cout << "Choose operation (+, -, *, /): ";
        std::cin >> operation;

        bool valid = true;
        double result = 0.0;

        switch (operation) {
            case '+':
                result = a + b;
                break;
            case '-':
                result = a - b;
                break;
            case '*':
                result = a * b;
                break;
            case '/':
                if (b == 0.0) {
                    std::cout << "Error: division by zero is not allowed.\n";
                    valid = false;
                } else {
                    result = a / b;
                }
                break;
            default:
                std::cout << "Invalid operation.\n";
                valid = false;
        }

        if (valid) {
            std::cout << "Result = " << result << "\n";
        }

        std::cout << "Calculate again? (y/n): ";
        std::cin >> again;
    }

    std::cout << "Calculator closed.\n";
    return 0;
}
