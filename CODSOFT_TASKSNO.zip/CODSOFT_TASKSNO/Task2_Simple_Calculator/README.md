# Task 2 — Simple Calculator

## Objective
Create a calculator that accepts two numbers and performs addition, subtraction, multiplication, or division.

## Features
- Addition
- Subtraction
- Multiplication
- Division
- Division-by-zero protection
- Invalid input handling
- Repeat calculations

## Compile

```bash
g++ -std=c++17 main.cpp -o task2
```

## Run

```bash
./task2
```
