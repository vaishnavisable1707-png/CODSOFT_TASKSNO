# Task 4 — To-Do List

## Objective
Build a console-based task manager that allows users to add, view, complete, and remove tasks.

## Features
- Add tasks
- View tasks
- Mark tasks completed
- Remove tasks
- Save tasks to `tasks.txt`
- Load tasks when the program starts

## Compile

```bash
g++ -std=c++17 main.cpp -o task4
```

## Run

```bash
./task4
```

The program creates `tasks.txt` in the working directory to persist tasks between runs.
