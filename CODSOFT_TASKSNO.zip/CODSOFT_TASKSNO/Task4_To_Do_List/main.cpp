#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <limits>

struct Task {
    std::string title;
    bool completed;
};

const std::string FILE_NAME = "tasks.txt";

void saveTasks(const std::vector<Task>& tasks) {
    std::ofstream file(FILE_NAME);

    if (!file) {
        std::cout << "Warning: could not save tasks.\n";
        return;
    }

    for (const Task& task : tasks) {
        file << (task.completed ? "1" : "0") << "|" << task.title << "\n";
    }
}

void loadTasks(std::vector<Task>& tasks) {
    std::ifstream file(FILE_NAME);
    if (!file) {
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        if (line.size() >= 2 && line[1] == '|') {
            Task task;
            task.completed = (line[0] == '1');
            task.title = line.substr(2);
            tasks.push_back(task);
        }
    }
}

void viewTasks(const std::vector<Task>& tasks) {
    if (tasks.empty()) {
        std::cout << "No tasks found.\n";
        return;
    }

    std::cout << "\n----------- TASKS -----------\n";
    for (std::size_t i = 0; i < tasks.size(); ++i) {
        std::cout << i + 1 << ". ["
                  << (tasks[i].completed ? 'X' : ' ')
                  << "] " << tasks[i].title << "\n";
    }
}

int readIndex(const std::vector<Task>& tasks, const std::string& prompt) {
    int index;

    while (true) {
        std::cout << prompt;
        if (std::cin >> index &&
            index >= 1 &&
            index <= static_cast<int>(tasks.size())) {
            return index - 1;
        }

        std::cout << "Invalid task number.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

int main() {
    std::vector<Task> tasks;
    loadTasks(tasks);

    int choice = 0;

    while (choice != 5) {
        std::cout << "\n=================================\n";
        std::cout << "          TO-DO LIST\n";
        std::cout << "=================================\n";
        std::cout << "1. Add task\n";
        std::cout << "2. View tasks\n";
        std::cout << "3. Mark task completed\n";
        std::cout << "4. Remove task\n";
        std::cout << "5. Exit\n";
        std::cout << "Choose an option: ";

        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid option.\n";
            continue;
        }

        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choice) {
            case 1: {
                std::string title;
                std::cout << "Enter task: ";
                std::getline(std::cin, title);

                if (title.empty()) {
                    std::cout << "Task cannot be empty.\n";
                    break;
                }

                tasks.push_back({title, false});
                saveTasks(tasks);
                std::cout << "Task added.\n";
                break;
            }

            case 2:
                viewTasks(tasks);
                break;

            case 3:
                if (tasks.empty()) {
                    std::cout << "No tasks to complete.\n";
                    break;
                }
                viewTasks(tasks);
                {
                    const int index = readIndex(tasks, "Task number: ");
                    tasks[index].completed = true;
                    saveTasks(tasks);
                    std::cout << "Task marked as completed.\n";
                }
                break;

            case 4:
                if (tasks.empty()) {
                    std::cout << "No tasks to remove.\n";
                    break;
                }
                viewTasks(tasks);
                {
                    const int index = readIndex(tasks, "Task number: ");
                    tasks.erase(tasks.begin() + index);
                    saveTasks(tasks);
                    std::cout << "Task removed.\n";
                }
                break;

            case 5:
                saveTasks(tasks);
                std::cout << "Tasks saved. Goodbye!\n";
                break;

            default:
                std::cout << "Please choose 1 to 5.\n";
        }
    }

    return 0;
}
