# Task 3 — Tic-Tac-Toe Game

## Objective
Build a console-based two-player Tic-Tac-Toe game using a 3x3 board.

## Features
- 3x3 game board
- Player X and Player O
- Turn switching
- Move validation
- Win detection
- Draw detection
- Replay option

## Compile

```bash
g++ -std=c++17 main.cpp -o task3
```

## Run

```bash
./task3
```
