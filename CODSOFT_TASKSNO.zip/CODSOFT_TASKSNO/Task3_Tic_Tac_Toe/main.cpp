#include <iostream>
#include <array>
#include <limits>

using Board = std::array<char, 9>;

void displayBoard(const Board& board) {
    std::cout << "\n";
    std::cout << " " << board[0] << " | " << board[1] << " | " << board[2] << "\n";
    std::cout << "---+---+---\n";
    std::cout << " " << board[3] << " | " << board[4] << " | " << board[5] << "\n";
    std::cout << "---+---+---\n";
    std::cout << " " << board[6] << " | " << board[7] << " | " << board[8] << "\n\n";
}

bool hasWon(const Board& b, char player) {
    const int wins[8][3] = {
        {0, 1, 2}, {3, 4, 5}, {6, 7, 8},
        {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
        {0, 4, 8}, {2, 4, 6}
    };

    for (const auto& line : wins) {
        if (b[line[0]] == player &&
            b[line[1]] == player &&
            b[line[2]] == player) {
            return true;
        }
    }
    return false;
}

bool isDraw(const Board& board) {
    for (char cell : board) {
        if (cell >= '1' && cell <= '9') {
            return false;
        }
    }
    return true;
}

int getMove(const Board& board) {
    int move;

    while (true) {
        std::cout << "Enter a position (1-9): ";

        if (std::cin >> move && move >= 1 && move <= 9 &&
            board[move - 1] >= '1' && board[move - 1] <= '9') {
            return move - 1;
        }

        std::cout << "Invalid or occupied position. Try again.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

int main() {
    char playAgain = 'y';

    std::cout << "=================================\n";
    std::cout << "         TIC-TAC-TOE GAME\n";
    std::cout << "=================================\n";

    while (playAgain == 'y' || playAgain == 'Y') {
        Board board = {'1','2','3','4','5','6','7','8','9'};
        char player = 'X';

        while (true) {
            displayBoard(board);
            std::cout << "Player " << player << "'s turn.\n";

            const int position = getMove(board);
            board[position] = player;

            if (hasWon(board, player)) {
                displayBoard(board);
                std::cout << "Player " << player << " wins!\n";
                break;
            }

            if (isDraw(board)) {
                displayBoard(board);
                std::cout << "It's a draw!\n";
                break;
            }

            player = (player == 'X') ? 'O' : 'X';
        }

        std::cout << "Play again? (y/n): ";
        std::cin >> playAgain;
    }

    std::cout << "Thanks for playing!\n";
    return 0;
}
