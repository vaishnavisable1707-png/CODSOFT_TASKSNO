# CODSOFT C++ Programming Internship

A complete C++ console-project repository prepared for the CodSoft C++ Programming Internship.

## Internship requirements

The provided CodSoft brief says that at least **3 tasks** must be completed successfully and that a separate GitHub repository should be maintained for the tasks. The brief lists five available tasks: Number Guessing Game, Simple Calculator, Tic-Tac-Toe Game, To-Do List, and Image Processing Tool. fileciteturn0file0L20-L30

This repository contains **all 5 tasks** so you can demonstrate more than the minimum requirement.

## Tasks

| Task | Project | Main concepts |
|---|---|---|
| 1 | Number Guessing Game | random numbers, loops, conditions |
| 2 | Simple Calculator | functions, switch, validation |
| 3 | Tic-Tac-Toe Game | arrays, functions, game logic |
| 4 | To-Do List | structs, vectors, file handling |
| 5 | Image Processing Tool | file I/O, pixel processing, PPM images |

The first three tasks directly follow the internship brief: the guessing game repeatedly gives high/low feedback, the calculator performs basic arithmetic, and Tic-Tac-Toe uses a 3x3 board with X/O, turns, win/draw checking, and replay. fileciteturn0file0L76-L109

Task 4 follows the brief's requested add/view/complete/remove functionality. fileciteturn0file0L111-L121

Task 5 follows the brief's image-processing direction, including loading/displaying images and operations such as filtering, brightness/contrast adjustment, crop/resize, and saving. This implementation intentionally uses the portable **PPM (P3)** image format so it can be compiled without an external image library. fileciteturn0file0L123-L135

## Repository structure

```text
CODSOFT_TASKSNO/
├── README.md
├── .gitignore
├── LICENSE
├── Task1_Number_Guessing_Game/
│   ├── main.cpp
│   └── README.md
├── Task2_Simple_Calculator/
│   ├── main.cpp
│   └── README.md
├── Task3_Tic_Tac_Toe/
│   ├── main.cpp
│   └── README.md
├── Task4_To_Do_List/
│   ├── main.cpp
│   └── README.md
└── Task5_Image_Processing_Tool/
    ├── main.cpp
    └── README.md
```

## Requirements

- C++ compiler with C++17 support
- Windows, Linux, or macOS
- VS Code / Code::Blocks / Visual Studio / any C++ IDE
- Git for GitHub upload

Check your compiler:

```bash
g++ --version
```

## Compile and run

From the repository root:

### Windows (MinGW g++)

```bash
g++ -std=c++17 Task1_Number_Guessing_Game/main.cpp -o task1.exe
task1.exe

g++ -std=c++17 Task2_Simple_Calculator/main.cpp -o task2.exe
task2.exe

g++ -std=c++17 Task3_Tic_Tac_Toe/main.cpp -o task3.exe
task3.exe

g++ -std=c++17 Task4_To_Do_List/main.cpp -o task4.exe
task4.exe

g++ -std=c++17 Task5_Image_Processing_Tool/main.cpp -o task5.exe
task5.exe
```

### Linux/macOS

```bash
g++ -std=c++17 Task1_Number_Guessing_Game/main.cpp -o task1
./task1
```

Repeat the same pattern for Tasks 2–5.

## Task 5 image format

Task 5 uses **PPM P3** text images. This keeps the project dependency-free.

Example PPM header:

```text
P3
4 4
255
```

The program can create a sample image from its menu, then load it and apply operations.

## Recommended internship demo

For a short demo video, show:

1. GitHub repository and folder structure.
2. Task 1 running and a correct guess.
3. Task 2 performing arithmetic.
4. Task 3 showing a win/draw.
5. Task 4 adding and completing tasks.
6. Task 5 loading a sample PPM and applying an operation.
7. The README and source code.

The internship brief also says a demo video should be created to showcase the work and that it can be shared on LinkedIn with `#codsoft`. fileciteturn0file0L32-L39

## GitHub upload

Create a GitHub repository named:

```text
CODSOFT_TASKSNO
```

Then open Command Prompt / PowerShell inside this folder:

```bash
git init
git add .
git commit -m "Complete CodSoft C++ internship tasks"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/CODSOFT_TASKSNO.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

## GitHub website method

1. Sign in to GitHub.
2. Create a new repository named `CODSOFT_TASKSNO`.
3. Keep it public if your internship submission requires a public repository.
4. Upload the repository files/folders.
5. Commit the changes.
6. Open the repository and copy its URL.
7. Submit that repository link in the CodSoft task submission form when it is provided.

## Notes

- Do not upload passwords, API keys, or personal credentials.
- Keep source code readable and commented.
- Use meaningful commit messages.
- Add screenshots of program output if desired.
- The repository is designed to exceed the minimum 3-task requirement.

## Author

**Vaishnavi Sable**

C++ Programming Internship — CodSoft
