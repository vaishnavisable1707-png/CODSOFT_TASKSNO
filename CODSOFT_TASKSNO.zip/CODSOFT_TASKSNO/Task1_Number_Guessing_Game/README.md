# Task 1 — Number Guessing Game

## Objective
Generate a random number and let the user guess it. The program tells the user whether the guess is too high or too low until the correct number is found.

## Features
- Random number from 1 to 100
- High/low feedback
- Attempt counter
- Input validation
- Play again option

## Compile

```bash
g++ -std=c++17 main.cpp -o task1
```

## Run

```bash
./task1
```

On Windows:

```powershell
g++ -std=c++17 main.cpp -o task1.exe
.\task1.exe
```
