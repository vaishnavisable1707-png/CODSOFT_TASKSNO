#include <iostream>
#include <random>
#include <limits>

int getGuess() {
    int guess;
    while (true) {
        std::cout << "Enter your guess (1-100): ";
        if (std::cin >> guess && guess >= 1 && guess <= 100) {
            return guess;
        }

        std::cout << "Invalid input. Please enter a number from 1 to 100.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

int main() {
    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_int_distribution<int> distribution(1, 100);

    char again = 'y';

    std::cout << "=================================\n";
    std::cout << "     NUMBER GUESSING GAME\n";
    std::cout << "=================================\n";

    while (again == 'y' || again == 'Y') {
        const int secret = distribution(generator);
        int attempts = 0;

        std::cout << "\nI have selected a number between 1 and 100.\n";

        while (true) {
            const int guess = getGuess();
            ++attempts;

            if (guess < secret) {
                std::cout << "Too low! Try again.\n";
            } else if (guess > secret) {
                std::cout << "Too high! Try again.\n";
            } else {
                std::cout << "Correct! You found the number in "
                          << attempts << " attempt(s).\n";
                break;
            }
        }

        std::cout << "Play again? (y/n): ";
        std::cin >> again;
    }

    std::cout << "Thanks for playing!\n";
    return 0;
}
