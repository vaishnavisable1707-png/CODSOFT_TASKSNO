# Task 5 — Image Processing Tool

## Objective
Build a simple C++ image-processing tool supporting loading, displaying, filtering, color adjustment, cropping/resizing, and saving.

## Why PPM?
To keep the internship project easy to compile, this implementation uses the portable **PPM P3** text image format. No third-party library is required.

## Supported operations
- Create a sample PPM image
- Load PPM P3 image
- Display basic image information
- Grayscale
- Brightness adjustment
- Contrast adjustment
- Resize using nearest-neighbor
- Crop
- Save processed image

## Compile

```bash
g++ -std=c++17 main.cpp -o task5
```

## Run

```bash
./task5
```

## Workflow

1. Choose `1` to create `sample.ppm`.
2. Choose `2` to load `sample.ppm`.
3. Apply an operation.
4. Choose `8` to save the processed image.
5. Open the resulting `.ppm` with an image viewer that supports PPM.

The task brief requests image loading/display, filters, color adjustments, crop/resize, saving, and a user-friendly interface. fileciteturn0file0L123-L135
