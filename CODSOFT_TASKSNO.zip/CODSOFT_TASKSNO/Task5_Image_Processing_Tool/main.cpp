#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

struct Pixel {
    int r = 0;
    int g = 0;
    int b = 0;
};

struct Image {
    int width = 0;
    int height = 0;
    int maxValue = 255;
    std::vector<Pixel> pixels;

    bool valid() const {
        return width > 0 && height > 0 &&
               pixels.size() == static_cast<std::size_t>(width * height);
    }

    Pixel& at(int x, int y) {
        return pixels[static_cast<std::size_t>(y * width + x)];
    }

    const Pixel& at(int x, int y) const {
        return pixels[static_cast<std::size_t>(y * width + x)];
    }
};

int clampChannel(int value) {
    return std::clamp(value, 0, 255);
}

bool loadPPM(const std::string& filename, Image& image) {
    std::ifstream file(filename);
    if (!file) {
        return false;
    }

    std::string magic;
    file >> magic;

    if (magic != "P3") {
        std::cout << "Only P3 PPM files are supported.\n";
        return false;
    }

    file >> image.width >> image.height >> image.maxValue;

    if (image.width <= 0 || image.height <= 0 ||
        image.maxValue <= 0) {
        return false;
    }

    image.pixels.resize(static_cast<std::size_t>(image.width * image.height));

    for (Pixel& pixel : image.pixels) {
        if (!(file >> pixel.r >> pixel.g >> pixel.b)) {
            return false;
        }

        pixel.r = clampChannel(pixel.r * 255 / image.maxValue);
        pixel.g = clampChannel(pixel.g * 255 / image.maxValue);
        pixel.b = clampChannel(pixel.b * 255 / image.maxValue);
    }

    image.maxValue = 255;
    return true;
}

bool savePPM(const std::string& filename, const Image& image) {
    if (!image.valid()) {
        return false;
    }

    std::ofstream file(filename);
    if (!file) {
        return false;
    }

    file << "P3\n";
    file << image.width << " " << image.height << "\n";
    file << "255\n";

    for (const Pixel& pixel : image.pixels) {
        file << clampChannel(pixel.r) << " "
             << clampChannel(pixel.g) << " "
             << clampChannel(pixel.b) << "\n";
    }

    return true;
}

void createSampleImage(const std::string& filename) {
    Image image;
    image.width = 8;
    image.height = 8;
    image.pixels.resize(64);

    for (int y = 0; y < image.height; ++y) {
        for (int x = 0; x < image.width; ++x) {
            Pixel& p = image.at(x, y);
            p.r = x * 32;
            p.g = y * 32;
            p.b = (x + y) * 16;
        }
    }

    savePPM(filename, image);
}

void grayscale(Image& image) {
    for (Pixel& p : image.pixels) {
        const int gray = static_cast<int>(
            0.299 * p.r + 0.587 * p.g + 0.114 * p.b
        );
        p.r = p.g = p.b = gray;
    }
}

void adjustBrightness(Image& image, int amount) {
    for (Pixel& p : image.pixels) {
        p.r = clampChannel(p.r + amount);
        p.g = clampChannel(p.g + amount);
        p.b = clampChannel(p.b + amount);
    }
}

void adjustContrast(Image& image, double factor) {
    for (Pixel& p : image.pixels) {
        p.r = clampChannel(static_cast<int>((p.r - 128) * factor + 128));
        p.g = clampChannel(static_cast<int>((p.g - 128) * factor + 128));
        p.b = clampChannel(static_cast<int>((p.b - 128) * factor + 128));
    }
}

bool resizeImage(Image& image, int newWidth, int newHeight) {
    if (newWidth <= 0 || newHeight <= 0 || !image.valid()) {
        return false;
    }

    Image result;
    result.width = newWidth;
    result.height = newHeight;
    result.maxValue = 255;
    result.pixels.resize(static_cast<std::size_t>(newWidth * newHeight));

    for (int y = 0; y < newHeight; ++y) {
        const int sourceY = y * image.height / newHeight;

        for (int x = 0; x < newWidth; ++x) {
            const int sourceX = x * image.width / newWidth;
            result.at(x, y) = image.at(sourceX, sourceY);
        }
    }

    image = result;
    return true;
}

bool cropImage(Image& image, int startX, int startY, int cropWidth, int cropHeight) {
    if (!image.valid() || cropWidth <= 0 || cropHeight <= 0 ||
        startX < 0 || startY < 0 ||
        startX + cropWidth > image.width ||
        startY + cropHeight > image.height) {
        return false;
    }

    Image result;
    result.width = cropWidth;
    result.height = cropHeight;
    result.maxValue = 255;
    result.pixels.resize(static_cast<std::size_t>(cropWidth * cropHeight));

    for (int y = 0; y < cropHeight; ++y) {
        for (int x = 0; x < cropWidth; ++x) {
            result.at(x, y) = image.at(startX + x, startY + y);
        }
    }

    image = result;
    return true;
}

void displayInfo(const Image& image) {
    if (!image.valid()) {
        std::cout << "No valid image loaded.\n";
        return;
    }

    std::cout << "Image: " << image.width << " x "
              << image.height << "\n";
    std::cout << "Format: PPM P3\n";
    std::cout << "Pixels: " << image.pixels.size() << "\n";
}

int readInt(const std::string& prompt) {
    int value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            return value;
        }

        std::cout << "Invalid number.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

int main() {
    Image image;
    int choice = 0;

    std::cout << "=================================\n";
    std::cout << "      IMAGE PROCESSING TOOL\n";
    std::cout << "=================================\n";
    std::cout << "Format: PPM P3 (dependency-free)\n";

    while (choice != 9) {
        std::cout << "\n----------- MENU -----------\n";
        std::cout << "1. Create sample image\n";
        std::cout << "2. Load PPM image\n";
        std::cout << "3. Display image information\n";
        std::cout << "4. Grayscale\n";
        std::cout << "5. Adjust brightness\n";
        std::cout << "6. Adjust contrast\n";
        std::cout << "7. Crop / resize\n";
        std::cout << "8. Save image\n";
        std::cout << "9. Exit\n";

        choice = readInt("Choose an option: ");

        switch (choice) {
            case 1: {
                const std::string filename = "sample.ppm";
                createSampleImage(filename);
                std::cout << "Created " << filename << ".\n";
                break;
            }

            case 2: {
                std::string filename;
                std::cout << "Enter PPM filename: ";
                std::cin >> filename;

                if (loadPPM(filename, image)) {
                    std::cout << "Image loaded successfully.\n";
                } else {
                    std::cout << "Could not load image.\n";
                }
                break;
            }

            case 3:
                displayInfo(image);
                break;

            case 4:
                if (!image.valid()) {
                    std::cout << "Load an image first.\n";
                } else {
                    grayscale(image);
                    std::cout << "Grayscale applied.\n";
                }
                break;

            case 5: {
                if (!image.valid()) {
                    std::cout << "Load an image first.\n";
                    break;
                }
                const int amount = readInt("Brightness (-255 to 255): ");
                adjustBrightness(image, amount);
                std::cout << "Brightness adjusted.\n";
                break;
            }

            case 6: {
                if (!image.valid()) {
                    std::cout << "Load an image first.\n";
                    break;
                }
                double factor;
                std::cout << "Contrast factor (1.0 = unchanged, 1.5 = stronger): ";
                std::cin >> factor;
                adjustContrast(image, factor);
                std::cout << "Contrast adjusted.\n";
                break;
            }

            case 7: {
                if (!image.valid()) {
                    std::cout << "Load an image first.\n";
                    break;
                }

                std::cout << "1. Resize\n2. Crop\n";
                const int subChoice = readInt("Choose: ");

                if (subChoice == 1) {
                    const int w = readInt("New width: ");
                    const int h = readInt("New height: ");
                    std::cout << (resizeImage(image, w, h)
                        ? "Image resized.\n"
                        : "Resize failed.\n");
                } else if (subChoice == 2) {
                    const int x = readInt("Start X: ");
                    const int y = readInt("Start Y: ");
                    const int w = readInt("Crop width: ");
                    const int h = readInt("Crop height: ");
                    std::cout << (cropImage(image, x, y, w, h)
                        ? "Image cropped.\n"
                        : "Crop failed. Check the boundaries.\n");
                } else {
                    std::cout << "Invalid option.\n";
                }
                break;
            }

            case 8: {
                if (!image.valid()) {
                    std::cout << "Load or create an image first.\n";
                    break;
                }

                std::string filename;
                std::cout << "Output filename (example: output.ppm): ";
                std::cin >> filename;

                if (savePPM(filename, image)) {
                    std::cout << "Image saved successfully.\n";
                } else {
                    std::cout << "Could not save image.\n";
                }
                break;
            }

            case 9:
                std::cout << "Goodbye!\n";
                break;

            default:
                std::cout << "Invalid option.\n";
        }
    }

    return 0;
}
